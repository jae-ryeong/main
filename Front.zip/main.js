<!DOCUMENT html>
<html>
    <head>
        <title>Something</title>
    </head>
</html>